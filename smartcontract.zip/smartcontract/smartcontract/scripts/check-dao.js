const hre = require("hardhat");

async function main() {
  const addr = process.env.ADDR;
  const dao = await hre.ethers.getContractAt("DominionDAO", addr);
  console.log("daoBalance:", (await dao.daoBalance()).toString());
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
