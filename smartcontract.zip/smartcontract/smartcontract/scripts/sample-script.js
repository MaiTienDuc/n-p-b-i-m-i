const hre = require("hardhat");

async function main() {
  const FirstSmartContract = await hre.ethers.getContractFactory(
    "FirstSmartcontract",
  );
  const firstSmartContract = await FirstSmartContract.deploy();

  await firstSmartContract.waitForDeployment();

  console.log(
    "FirstSmartContract deployed to:",
    await firstSmartContract.getAddress(),
  );
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
