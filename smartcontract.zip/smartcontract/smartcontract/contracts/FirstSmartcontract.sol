// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

contract FirstSmartcontract {
    string public message = "Hello Hardhat";
}